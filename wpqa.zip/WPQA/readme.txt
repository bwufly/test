=== WPQA - The WordPress Questions And Answers Plugin ===
Contributors: 2code
Tags: question, Answer, Badges, Points, Q & A, Question and answer, Questions, Answers,
Donate link: https://2code.info/wpqa/
Requires at least: 4.0
Tested up to: 5.8
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Question and answer plugin with point and badges system.

== Description ==

The plugin main page: https://2code.info/wpqa/

Question and answer plugin with point and badges system.

= Plugin Features =
* Questions and answers
* Point system.
* Badges system.
* Ask users a questions.
* Select best answer.
* Report system for the questions and answers.
* Follow questions.
* Add questions to favorites.
* Notifications system.
* Activity log system.
* Edit profile.
* Follow users.
* Poll questions.
* And more...

== Installation ==
Installing "WPQA" can be done either by using the following steps:

1. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What is the WPQA for? =
This will help you to questions and answers pages in your site and can give the user points to show a badges.

= How can I use the plugin? =
just see this demo :
https://2code.info/wpqa/